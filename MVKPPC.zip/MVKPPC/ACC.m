
%%

   %���ݸ����ı�ǩ����ʵ�ı�ǩ������׼ȷ�� 

%%
function acc = Acc(ground_truth_label,cluster_label)
    
    %�õ���ʵ�ı�ǩ�в��ظ���Ԫ�غ��䳤��
    ground_truth_label_unique = unique(ground_truth_label);
    ground_truth_label_num = length(ground_truth_label_unique);

    %�õ������ǩ�в��ظ���Ԫ�غ��䳤��
    cluster_label_unique = unique(cluster_label);
    cluster_labeled_num = length(cluster_label_unique);
    
    
    %ȡ���������нϳ�����һ������һ������
    max_length = max( ground_truth_label_num, cluster_labeled_num);
    G = zeros(max_length, max_length);
    
    for i = 1: ground_truth_label_num
        
        %�Ӳ��ظ�������һ������ѡ��Ԫ�أ���ȡ���ǵ�λ��,index���ص��Ǻ�
        %cluster_label��С��ͬ��һ�����飬Ϊtrue���ʾ��ǰ���Ӧ��λ��
        
        index1 = cluster_label ==  ground_truth_label_unique(1, i);
        
        %����ʵ�ı�ǩ��ѡ��ÿ�����ظ���Ԫ�أ����õ���������ʵ�ķֲ��е�λ��
        for j = 1 :  cluster_labeled_num
            
            index2 = ground_truth_label == cluster_label_unique(1,j);
            
            %��˵Ľ������G������
            G(i, j) = sum(index1.*index2);
            
        end
      
    end
    
    %ʹ���������㷨����ӳ������ŵľ���
    [index] = munkres(-G);
    
    
    %��ӳ�����Ž��ת��Ϊһ���洢��ӳ�����ź��ǩ˳���������
    [temp] = MarkReplace(index);
    
    %�õ�һ���µı�ǩ
    new_label = zeros(size(cluster_label));
    
    for i = 1 : cluster_labeled_num
        
        new_label(cluster_label ==  cluster_label_unique(i)) = temp(i);
    
    end
    
    %T��һ���������飬�����Ӧ���ˣ��򷵻�1����1��Ӧ�ľ�����ȷ����ı�ǩ
    T =  ground_truth_label == new_label;
    
    acc = sum(T) / length(new_label);
    
    
end

function [assignment] = munkres(costMat)
% MUNKRES   Munkres Assign Algorithm
%
% [ASSIGN,COST] = munkres(COSTMAT) returns the optimal assignment in ASSIGN
% with the minimum COST based on the assignment problem represented by the
% COSTMAT, where the (i,j)th element represents the cost to assign the jth
% job to the ith worker.
%
 
% This is vectorized implementation of the algorithm. It is the fastest
% among all Matlab implementations of the algorithm.
 
% Examples
% Example 1: a 5 x 5 example
%{
[assignment,cost] = munkres(magic(5));
[assignedrows,dum]=find(assignment);
disp(assignedrows'); % 3 2 1 5 4
disp(cost); %15
%}
% Example 2: 400 x 400 random data
%{
n=5;
A=rand(n);
tic
[a,b]=munkres(A);
toc                
%}
 
% Reference:
% "Munkres' Assignment Algorithm, Modified for Rectangular Matrices",
% http://csclab.murraystate.edu/bob.pilgrim/445/munkres.html
 
% version 1.0 by Yi Cao at Cranfield University on 17th June 2008
 
assignment = false(size(costMat));
 
costMat(costMat~=costMat)=Inf;
validMat = costMat<Inf;
validCol = any(validMat);
validRow = any(validMat,2);
 
nRows = sum(validRow);
nCols = sum(validCol);
n = max(nRows,nCols);
if ~n
    return
end
     
dMat = zeros(n);
dMat(1:nRows,1:nCols) = costMat(validRow,validCol);
 
%*************************************************
% Munkres' Assignment Algorithm starts here
%*************************************************
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   STEP 1: Subtract the row minimum from each row.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 dMat = bsxfun(@minus, dMat, min(dMat,[],2));
 
%************************************************************************** 
%   STEP 2: Find a zero of dMat. If there are no starred zeros in its
%           column or row start the zero. Repeat for each zero
%**************************************************************************
zP = ~dMat;
starZ = false(n);
while any(zP(:))
    [r,c]=find(zP,1);
    starZ(r,c)=true;
    zP(r,:)=false;
    zP(:,c)=false;
end
 
while 1
%**************************************************************************
%   STEP 3: Cover each column with a starred zero. If all the columns are
%           covered then the matching is maximum
%**************************************************************************
    primeZ = false(n);
    coverColumn = any(starZ);
    if ~any(~coverColumn)
        break
    end
    coverRow = false(n,1);
    while 1
        %**************************************************************************
        %   STEP 4: Find a noncovered zero and prime it.  If there is no starred
        %           zero in the row containing this primed zero, Go to Step 5. 
        %           Otherwise, cover this row and uncover the column containing
        %           the starred zero. Continue in this manner until there are no
        %           uncovered zeros left. Save the smallest uncovered value and
        %           Go to Step 6.
        %**************************************************************************
        zP(:) = false;
        zP(~coverRow,~coverColumn) = ~dMat(~coverRow,~coverColumn);
        Step = 6;
        while any(any(zP(~coverRow,~coverColumn)))
            [uZr,uZc] = find(zP,1);
            primeZ(uZr,uZc) = true;
            stz = starZ(uZr,:);
            if ~any(stz)
                Step = 5;
                break;
            end
            coverRow(uZr) = true;
            coverColumn(stz) = false;
            zP(uZr,:) = false;
            zP(~coverRow,stz) = ~dMat(~coverRow,stz);
        end
        if Step == 6
            % *************************************************************************
            % STEP 6: Add the minimum uncovered value to every element of each covered
            %         row, and subtract it from every element of each uncovered column.
            %         Return to Step 4 without altering any stars, primes, or covered lines.
            %**************************************************************************
            M=dMat(~coverRow,~coverColumn);
            minval=min(min(M));
            if minval==inf
                return
            end
            dMat(coverRow,coverColumn)=dMat(coverRow,coverColumn)+minval;
            dMat(~coverRow,~coverColumn)=M-minval;
        else
            break
        end
    end
    %**************************************************************************
    % STEP 5:
    %  Construct a series of alternating primed and starred zeros as
    %  follows:
    %  Let Z0 represent the uncovered primed zero found in Step 4.
    %  Let Z1 denote the starred zero in the column of Z0 (if any).
    %  Let Z2 denote the primed zero in the row of Z1 (there will always
    %  be one).  Continue until the series terminates at a primed zero
    %  that has no starred zero in its column.  Unstar each starred
    %  zero of the series, star each primed zero of the series, erase
    %  all primes and uncover every line in the matrix.  Return to Step 3.
    %**************************************************************************
    rowZ1 = starZ(:,uZc);
    starZ(uZr,uZc)=true;
    while any(rowZ1)
        starZ(rowZ1,uZc)=false;
        uZc = primeZ(rowZ1,:);
        uZr = rowZ1;
        rowZ1 = starZ(:,uZc);
        starZ(uZr,uZc)=true;
    end
end
%���ɱ�ǩ����
assignment(validRow,validCol) = starZ(1:nRows,1:nCols);

%�����ǩӳ�����ⲻ��Ҫ����Ȩ��cost���ʽ���ע��
%cost = 0;
%cost = sum(costMat(assignment));

end
%���洢��ǩ˳��Ŀռ����ת��Ϊһ��������
function [assignment] = MarkReplace(MarkMat)

[rows,cols]=size(MarkMat);

assignment=zeros(1,cols);

for i=1:rows
    for j=1:cols
        if MarkMat(i,j)==1
            assignment(1,j)=i;
        end
    end
end

end
