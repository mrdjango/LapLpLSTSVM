
%input  
%1  row data which contains all view
%2  initalization label
%3  parameter which contrals fuzzy plane
%4  kernel function
%5  the number of cluster(equals to plane)
%output
%enhanced label
function pY = MPC(data,Y,c,FunPara, c_num)
    
   

    r=0.01;   
    
    %the number of view
    V = size(data,2);
    
    %the number of sample
    s = size(data{1}.X, 1);
    
    %initialization array of weight 
    anew = 1/ V * ones(V,1);
    
    %array of weight
    a = zeros(V,1);
    
    %k = max(Y);
    
    %parameter which control iteration partly
    p=0;
    
    %kernel function
    kerfPara.type = FunPara.kerfPare.type;
    k = c_num;
    
    while(norm(a-anew)>=0.001 && p~=20)
        a = anew;
        z = 0;
        pYnew = zeros(s,1);
        
        %label not change or up to the number of iteration
        while(~isempty(find(Y ~= pYnew, 1)) && z~=1000)   
            
            pYnew = Y;
            
            z=z+1;
            
            % update plane W
            for j=1:V
                
                %loss of funciton
                l=0;
                
                for i=1:k
                    tA = data{j}.X((Y==i),:); % the label equals to i
                    tB = data{j}.X((Y~=i),:); % the label except i
                    mi = size(tA,1);  %the number of somple which label equals to i
                    
                    %exist sample which label number equals to i
                    if ~isempty(find(Y == i, 1))
                        
                        %get loss to corresponding to view and patameter of plane
                        [VV{j}.L,VV{j}.W(i,:)] = GepOneSide(tA,tB,c);
                        
                        %cumulate the loss
                        l = l + VV{j}.L;
                    end   
                end

             VV{j}.L=l;
            end
    
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Predict and output pY
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
            
            if strcmp(kerfPara.type,'lin')
                
                % s is the number of sample, and k is the number of plane,
                % d is a indicate matrix, the label of sample i is min
                % value for column

                d = zeros(s,k);    
                for i=1:V  
                    
                    %the number of feature
                    t = size(data{i}.X,2);
                  
                    d =d + a(i,1) * abs(data{i}.X * VV{i}.W(:,1:t)' + ones(s,1) * VV{i}.W(:,t+1)');
                end
                
                pY=d;
               
           else
              d = zeros(s,k);
              for i=1:V
                  
                  d= d + a(i,1) * abs(data{i}.X * VV{i}.W(:,1:s)' + ones(s,1) * VV{i}.W(:,s + 1)');
              end
              pY=d;
            end
           
       %the min number is lable    
       [tmp,pY] = min(pY');
       
        
    
        
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % update parameters
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
        l=0;
        for i=1:V
            l = l + (r * VV{i}.L)^(1/(1-r));
        end
        
        for i=1:V
            anew(i,:)=((r*VV{i}.L)^(1/(1-r)))/l;
        end
    end
end