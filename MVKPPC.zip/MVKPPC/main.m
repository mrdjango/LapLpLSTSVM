clear all
close all

load('mnist.mat');
%load('BBCSport.mat');
%load('MSRC_V1.mat');
%load('UCI_Digits.mat');

%view{1,1} = 'fou'; % 200 * 76
%view{2,1} = 'kar'; % 200 * 64
%view{3,1} = 'fac'; % 200 * 216
%view{4,1} = 'pix'; % 200 * 240
%view{5,1} = 'zer'; % 200 * 47
%view{6,1} = 'mor'; % 200 * 6  

%X_v{1}= load(['./multifeat/',view{1,1},'.scaled.txt']);
%X_v{2}= load(['./multifeat/',view{2,1},'.scaled.txt']);
%X_v{3}= load(['./multifeat/',view{3,1},'.scaled.txt']);
%X_v{4}= load(['./multifeat/',view{4,1},'.scaled.txt']);
%X_v{5}= load(['./multifeat/',view{5,1},'.scaled.txt']);
%X_v{6}= load(['./multifeat/',view{6,1},'.scaled.txt']);

%number of view
view_num = 6;

%number of sample
sample_num = 800;

for i = 1 : view_num       
    d{i}.X = fea{i}(1:sample_num,:);
end

%turth label 
label = [];
label = gt(1:sample_num);

%selected view data
x = d{2}.X;

%number of K near neighbor
knn = 2;

%number of cluster
c_num = 4;

Y = Initialization(x, c_num, knn);

acc = ACC(label', Y');
nmi = NMI(label', Y');
purity = PURITY(label', Y')


FunPara.kerfPare.type = 'lin';

disp(acc);



Y = MPC(d, Y, 1,FunPara,c_num);
acc_final = ACC(label', Y);








