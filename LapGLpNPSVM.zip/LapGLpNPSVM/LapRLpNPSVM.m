function [PredictY, Times,loss_A, loss_B,v1,v2] = LapRLpNPSVM(Data, TestData, FunPara,knn) 
tic;
% Input:
%   Atrain: Positive class data matrix. Each row vector of Atrain is a data point.
%   Btrain: Positive class data matrix. Each row vector of Btrain is a data point.
%   delta: regularization term parameter.
%   FunPara.p: p in Lp-norm distance 
%   FunPara.q: q in Lq-norm regularization term 
%   FunPara.delta: parameter \delta
%   FunPara.sigma: parameter \sigma 
%   w0: Initial hyperplane direction and bias
%   itmax: Maximun iteration term num
%   epsmax: Tolerance
% 
% % % % Usage eample:
%   Atrain = rand(30,2);
%   Btrain = rand(30,2);
%   FunPara.p = 1; 
%   FunPara.q = 2;
%   FunPara.delta = 0.1;
%   FunPara.sigma = 0.1;
%   w0 = ones(size(Atrain,2) + 1,1); % Initialization
%   itmax = 20;
%   epsmax = 10^(-3);
%   [w1, b1, w2, b2] = RLpNPSVM(Atrain,Btrain,FunPara,w0,itmax,epsmax);
% 
% Reference:
%    Generalized elastic net Lp-norm nonparallel support vector machine
%    Chun-Na Li,Pei-Wei Ren, Yuan-Hai Shao, Ya-Fen Ye
%    Version 2.0 -- June/2019
%    Written by Pei-Wei Ren and Chun-Na Li (na1013na@163.com)

Atrain= Data.X((Data.Y==1),:);
Btrain = Data.X((Data.Y==-1),:);
Utrain=Data.X;

m = size(Data.X,1);
n = size(Data.X,2);

Rp = FunPara.p;
Rq = FunPara.q;

r1 = FunPara.r1;
r2 = FunPara.r2;
r3 = r2;

% w0 = ones(size(Atrain,2) + 1,1);
w0 = rand(size(Atrain,2) + 1,1);
itmax = 20;
epsmax = 10^(-3);

kerfPara = FunPara.kerfPara;
[nSmpA, nFea] = size(Atrain);
[nSmpB, ~] = size(Btrain);
iter = 0;
wp0 = w0;
wn0 = w0;
epsWX = 10^-4;
epsW = 10^-4;
Atrainbar = [Atrain,ones(size(Atrain,1),1)]';
Btrainbar = [Btrain,ones(size(Btrain,1),1)]';

L = laplacianSun2(Data.X,knn);
L=(L+L')/2;
[V U]=eig(L);
Utr=U^(1/2)*V*[Utrain,ones(size(Utrain,1),1)];
Utrainbar=Utr';
nSmp=size(Utrainbar,2);

loss_A = [];
loss_B = [];

while 1 
    %%%%%%%%%%%%%%%%%%
% % %     For A
    %%%%%%%%%%%%%%%%%%
    iter = iter + 1;
    Ht_A = zeros(nFea+1, nFea+1);
    ht_A = zeros(nFea+1,1);
    for i = 1:nSmpA
        Atrainbari = Atrainbar(:,i);
        Ht_A = Ht_A + (Atrainbari.*Atrainbari')/abs(wp0'*Atrainbari + epsWX).^(2 - Rp);
    end
    for i = 1:nSmpB
        ht_A = ht_A + abs(wp0'*Btrainbar(:,i))^(Rp-1)*sign(wp0'*Btrainbar(:,i))*Btrainbar(:,i);
    end
    
    Ht_U1 = zeros(size(Utrainbar,1),size(Utrainbar,1));
    for i = 1:nSmp
        Utrainbari = Utrainbar(:,i); 
        Ht_U1 = Ht_U1 + (Utrainbari*Utrainbari')/abs(wp0'*Utrainbari + epsWX).^(2 - Rp);
    end
    
    
    q_A = (abs(wp0) + epsW).^( Rq - 2);     
    Ht_Ar = r1*diag(q_A);
    
    [s1,~]=size(Ht_Ar);
    Ht_A = Ht_A + Ht_Ar + r2*eye(s1)+r3*Ht_U1;
    wp = (Ht_A\ht_A)/(ht_A'*inv(Ht_A)*ht_A);
   
    %%%%%%%%%%%%%%%%%%
% % %     For B
    %%%%%%%%%%%%%%%%%%
    Ht_B = zeros(nFea+1, nFea+1);
    ht_B = zeros(nFea+1,1);
    for i = 1:nSmpB
        Btrainbari = Btrainbar(:,i);
        Ht_B = Ht_B + (Btrainbari.*Btrainbari')/abs(wp0'*Btrainbari + epsWX).^(2 - Rp);
    end
    for i = 1:nSmpA
        ht_B = ht_B + abs(wn0'*Atrainbar(:,i))^(Rp-1)*sign(wn0'*Atrainbar(:,i))*Atrainbar(:,i);
    end
    Ht_U2 = zeros(size(Utrainbar,1),size(Utrainbar,1));
    for j = 1:nSmp
        Utrainbarj = Utrainbar(:,j); 
        Ht_U2 = Ht_U2 + (Utrainbarj*Utrainbarj')/abs(wn0'*Utrainbarj + epsWX).^(2 - Rp);
    end
    
    q_B = (abs(wn0) + epsW).^(Rq - 2);
    
    Ht_Br = r1*diag(q_B);
    [s2,~]=size(Ht_Br);
    
    Ht_B = Ht_B + Ht_Br + r2*eye(s2)+r3*Ht_U2;
    wn = (Ht_B\ht_B)/(ht_B'*inv(Ht_B)*ht_B);
    
    loss_A = [loss_A, wp0'*Ht_A*wp0];
    loss_B = [loss_B, wn0'*Ht_B*wn0];
    
   if max(abs(wp-wp0))<epsmax && max(abs(wn-wn0))<epsmax  || iter>=itmax
%         if iter >= itmax
        break;
   end
%     loss_A = [loss_A, sum(abs(wp-wp0),1)];
%     loss_B = [loss_B, sum(abs(wn-wn0),1)];
    wn0 = wn;
    wp0 = wp;
    
    
end


v1 = wp;
v2 = wn;

m3 = size(TestData, 1);
e = ones(m3,1);
K = [TestData, e];
Times = toc;
if ~strcmp(kerfPara.type,'lin')    
    w1 = sqrt(v1(1:m)'*K*v1(1:m));
    w2 = sqrt(v2(1:m)'*K*v2(1:m));
    K = [kernelfun(TestX,kerfPara,Data.X),e];
else
	w1 = sqrt(v1(1:n)'*v1(1:n));
    w2 = sqrt(v2(1:n)'*v2(1:n));
    K = [TestData, e];    
end
PredictY = sign(abs(K*v2/w2)-abs(K*v1/w1));
end








