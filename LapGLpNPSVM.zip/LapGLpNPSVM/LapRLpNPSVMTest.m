function [accura,Times,loss_A,loss_B,v1,v2] = LapRLpNPSVMTest(X, label,p,q,knn)
    NN=size(X,1);

    A=X(find(label==1),:);
    B=X(find(label==-1),:);
    view1=[A;B];
    
    n=size(view1,1);
    h1=round(0.08*n);
    h2=round(0.6*n);

    add = 10233;
    nn=5;
    times = [];
    for iter=1:nn
        iter;
        t1=clock;
        seed =2^iter+add; randn('seed',seed), rand('seed',seed);
        S=randperm(NN);
        ltrain=S(1:h1);
        utrain=S(h1+1:h2);
        test=S(h2+1:end);
        Xtr.data=view1(ltrain,:);
        Xtr.L=label(ltrain,:);
        Xtr.u=view1(utrain,:);
        Xte.data=view1(test,:);
        Xte.L=label(test,:);
        [nu,mu]=funLapRLpNPSVM(Xtr,p,q,knn);
%         nu=1;
%         mu=1;
         FunPara.r1=nu;
         FunPara.r2=mu;
         FunPara.p=p;
         FunPara.q=q;
         FunPara.kerfPara.type = 'lin';
         Data.X=[Xtr.data;Xtr.u];
         Data.Y=[Xtr.L;zeros(size(Xtr.u,1),1)];
         [pre, time,loss_A,loss_B,v1,v2]=LapRLpNPSVM(Data,Xte.data,FunPara,knn);
         times = [times time];
         accura(iter,:)=length(find(abs(pre-Xte.L)<1e-5))/length(pre);
         iter
    end
        Times = sum(time)/ nn;
        accura = accura';
        temp = accura; 
        accura = [accura mean(temp)];
        accura = [accura std(temp)];
    end