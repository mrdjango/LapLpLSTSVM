%funLapSVM_Rg.m
%Shiliang Sun, 2010-6-27, 2011-1-16, 2012-3-30

function [p,q,pre]=MvTSVM(xtr,xte,O,r1,r2)
M=size(xtr,2);
type=1;
sigma=1;
for i=1:M
    K{i}.A=makekernel(xtr{i}.A,xtr{i}.data,type,sigma);
    K{i}.K=makekernel(xtr{i}.data,xtr{i}.data,type,sigma);
    K{i}.Ker=[K{i}.K ones(size(K{i}.K,1),1)];
    K{i}.A=[K{i}.A ones(size(K{i}.A,1),1)];
    K{i}.B=makekernel(xtr{i}.B,xtr{i}.data,type,sigma);
    K{i}.B=[K{i}.B ones(size(K{i}.B,1),1)];
    K{i}.L=xtr{i}.L;
    K{i}.test=makekernel(xte{i}.data,xtr{i}.data,type,sigma);
end
% E1=[(2*r1+O(1,:))*K{1}.A'*K{1}.A -r1*K{1}.A'*K{2}.A -r1*K{1}.A'*K{3}.A; -r1*K{2}.A'*K{1}.A (2*r1+O(2,:))*K{2}.A'*K{2}.A -r1*K{2}.A'*K{3}.A;-r1*K{3}.A'*K{1}.A -r1*K{3}.A'*K{2}.A (2*r1+O(3,:))*K{3}.A'*K{3}.A];
E1=[2*r1*K{1}.Ker'*K{1}.Ker+O(1,:)*K{1}.A'*K{1}.A -r1*K{1}.Ker'*K{2}.Ker -r1*K{1}.Ker'*K{3}.Ker; -r1*K{2}.Ker'*K{1}.Ker 2*r1*K{2}.Ker'*K{2}.Ker+O(2,:)*K{2}.A'*K{2}.A -r1*K{2}.Ker'*K{3}.Ker;-r1*K{3}.Ker'*K{1}.Ker -r1*K{3}.Ker'*K{2}.Ker 2*r1*K{3}.Ker'*K{3}.Ker+O(3,:)*K{3}.A'*K{3}.A];
E1=(E1+E1')/2;
B=blkdiag(K{1}.B,K{2}.B,K{3}.B);
A=blkdiag(K{1}.A,K{2}.A,K{3}.A);
% E2=[(2*r1+O(1,:))*K{1}.B'*K{1}.B -r1*K{1}.B'*K{2}.B -r1*K{1}.B'*K{3}.B; -r1*K{2}.B'*K{1}.B (2*r1+O(2,:))*K{2}.B'*K{2}.B -r1*K{2}.B'*K{3}.B;-r1*K{3}.B'*K{1}.B -r1*K{3}.B'*K{2}.B (2*r1+O(3,:))*K{3}.B'*K{3}.B];
E2=[2*r1*K{1}.Ker'*K{1}.Ker+O(1,:)*K{1}.B'*K{1}.B -r1*K{1}.Ker'*K{2}.Ker -r1*K{1}.Ker'*K{3}.Ker; -r1*K{2}.Ker'*K{1}.Ker 2*r1*K{2}.Ker'*K{2}.Ker+O(2,:)*K{2}.B'*K{2}.B -r1*K{2}.Ker'*K{3}.Ker;-r1*K{3}.Ker'*K{1}.Ker -r1*K{3}.Ker'*K{2}.Ker 2*r1*K{3}.Ker'*K{3}.Ker+O(3,:)*K{3}.B'*K{3}.B];
E2=(E2+E2')/2;
 temp1=max(eig(E1));
 temp2=max(eig(E2));
E1=E1+0.000001*temp1*eye(size(E1,1));
E2=E2+0.000001*temp2*eye(size(E2,1));
n1=size(B,1);
n2=size(A,1);
e1=ones(n1,1);
e2=ones(n2,1);
cvx_begin
variable a(n1,1);
minimize(-a'*e1+0.5*a'*B*inv(E1)*B'*a)
subject to
a>=0;
a<=r2;
cvx_end

cvx_begin
variable b(n2,1);
minimize(-b'*e2+0.5*b'*A*inv(E2)*A'*b)
subject to
b>=0;
b<=r2;
cvx_end

n=size(K{1}.L,1);

w=1/2*inv(E1)*B'*a;
w1=w(1:n,:);
p1=w(n+1,:);
w2=w(n+2:2*n+1,:);
p2=w(2*n+2,:);
w3=w(2*n+3:3*n+2,:);
p3=w(3*n+3,:);
u=1/2*inv(E2)*A'*b;
u1=u(1:n,:);
q1=u(n+1,:);
u2=u(n+2:2*n+1,:);
q2=u(2*n+2,:);
u3=u(2*n+3:3*n+2,:);
q3=u(3*n+3,:);

nn=size(K{i}.test,1);
 for cvtest=1:nn
        d1=O(1,:)*abs(K{1}.test*w1+p1)/sqrt(w1'*K{1}.K*w1)+O(2,:)*abs(K{2}.test*w2+p2)/sqrt(w2'*K{2}.K*w2)+O(3,:)*abs(K{3}.test*w3+p3)/sqrt(w3'*K{3}.K*w3);
        d2=O(1,:)*abs(K{1}.test*u1+q1)/sqrt(u1'*K{1}.K*u1)+O(2,:)*abs(K{2}.test*u2+q2)/sqrt(u2'*K{2}.K*u2)+O(3,:)*abs(K{3}.test*u3+q3)/sqrt(u3'*K{3}.K*u3);
                   if(d1(cvtest,:)>=d2(cvtest,:))
                        Yt(cvtest,:)=-1;
                   else
                        Yt(cvtest,:)=1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt);
% p=[norm(K{1}.A*[w1;p1])^2/(w1'*K{1}.K*w1);norm(K{2}.A*[w2;p2])^2/(w2'*K{2}.K*w2);norm(K{3}.A*[w3;p3])^2]/(w3'*K{3}.K*w3);
% q=[norm(K{1}.B*[u1;q1])^2/(u1'*K{1}.K*u1);norm(K{2}.B*[u2;q2])^2/(u2'*K{2}.K*u2);norm(K{3}.B*[u3;q3])^2]/(u3'*K{3}.K*u3);
p=[norm(K{1}.A*[w1;p1])^2;norm(K{2}.A*[w2;p2])^2;norm(K{3}.A*[w3;p3])^2]
q=[norm(K{1}.B*[u1;q1])^2;norm(K{2}.B*[u2;q2])^2;norm(K{3}.B*[u3;q3])^2];
