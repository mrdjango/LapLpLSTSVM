clear
view{1,1} = 'fou'; % 200 * 76
view{2,1} = 'kar'; % 200 * 64
view{3,1} = 'fac'; % 200 * 216
view{4,1} = 'pix'; % 200 * 240
view{5,1} = 'zer'; % 200 * 47
view{6,1} = 'mor'; % 200 * 6  
%X_v1 = load(['./multifeat/mfeat-',view{v1,1},'.txt']); 
%X_v2 = load(['./multifeat/mfeat-',view{v2,1},'.txt']);
X_v{1}= load(['./multifeat/',view{1,1},'.scaled.txt']);
X_v{2}= load(['./multifeat/',view{2,1},'.scaled.txt']);
X_v{3}= load(['./multifeat/',view{3,1},'.scaled.txt']);
X_v{4}= load(['./multifeat/',view{4,1},'.scaled.txt']);
X_v{5}= load(['./multifeat/',view{5,1},'.scaled.txt']);
X_v{6}= load(['./multifeat/',view{6,1},'.scaled.txt']);

for i=1:1:6
    X{i}.A=X_v{i}(201:400,:);
    X{i}.B=X_v{i}(1401:1600,:);  
end




M=3;
h=80;
NN=200;
add=102333;
nn=5;
for iter=1
    iter;
    t1=clock;
    seed =2^iter+add; randn('seed',seed), rand('seed',seed);
    S=randperm(NN);
    train=S(1:h);
    test=S(h+1:end);
    for i=1:M
        Xtr{i}.A=X{i}.A(train,:);
        Xtr{i}.B=X{i}.B(train,:);
        XV{i}.A=X{i}.A(train,:);
        XV{i}.B=X{i}.B(train,:);
        Xtr{i}.data=[X{i}.A(train,:);X{i}.B(train,:)];
        Xtr{i}.L=[ones(size(X{i}.A(train,:),1),1);-ones(size(X{i}.B(train,:),1),1)];
        Xte{i}.data=[X{i}.A(test,:);X{i}.B(test,:)];
        Xte{i}.L=[ones(size(X{i}.A(test,:),1),1);-ones(size(X{i}.B(test,:),1),1)];
        XV{i}.L=[ones(size(X{i}.A(test,:),1),1);-ones(size(X{i}.B(test,:),1),1)];
    end
    O=zeros(M,1)/M;
    Oq=ones(M,1)/M;
    Op=ones(M,1)/M;
    z=0;r=0.1;
   [p,q,acc,nu,mu]=funMvTSVM(XV,Op);
   [p,q,accura(iter,:)]=MvTSVM(Xtr,Xte,Oq,nu,mu);
end



 