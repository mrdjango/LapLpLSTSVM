% Figures, examples, and exercises from the book [http://stanford.edu/~boyd/cvxbook Convex Optimization]
%
%  Ch04_cvx_opt_probs/     - Chapter 4: Convex optimization problems
%  Ch05_duality/           - Chapter 5: Duality
%  Ch06_approx_fitting/    - Chapter 6: Approximation and fitting
%  Ch07_statistical_estim/ - Chapter 7: Statistical estimation
%  Ch08_geometric_probs/   - Chapter 8: Geometric problems
%  Ch11_intpt_methods/     - Chapter 11: Interior-point methods
help Contents
