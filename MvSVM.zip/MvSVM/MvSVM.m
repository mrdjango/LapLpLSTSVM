%funLapSVM_Rg.m
%Shiliang Sun, 2010-6-27, 2011-1-16, 2012-3-30

function [p,pre]=MvSVM(xtr,xte,O,r1,r2)
M=size(xtr,2);
type=1;
sigma=1;
for i=1:M
    K{i}.train=makekernel(xtr{i}.data,xtr{i}.data,type,sigma);
    K{i}.L=xtr{i}.L;
    K{i}.test=makekernel(xte{i}.data,xtr{i}.data,type,sigma);
end
Y1=diag(xtr{1}.L); 
n1=size(xtr{i}.data,1);
e=ones(n1,1);
E=ones(n1,n1);

S1=[Y1 zeros(n1,n1) zeros(n1,n1) -E E -E E zeros(n1,n1) zeros(n1,n1)];
S2=[zeros(n1,n1) Y1 zeros(n1,n1) E -E zeros(n1,n1) zeros(n1,n1) -E E];
S3=[zeros(n1,n1) zeros(n1,n1) Y1 zeros(n1,n1) zeros(n1,n1) E -E E -E];
SS{1}.S=S1;
SS{2}.S=S2;
SS{3}.S=S3;
H=S1'*K{1}.train*S1/O(1,:)+S2'*K{2}.train*S2/O(2,:)+S3'*K{3}.train*S3/O(3,:);
H=(H+H')/2;
p=[-ones(3*n1,1);0.01*ones(6*n1,1)];
b=[r1*ones(3*n1,1);r2*ones(3*n1,1)];
EE=[E E];
w1=[e'*S1;e'*S2;e'*S3];
A=blkdiag(blkdiag(E,E,E),blkdiag(EE,EE,EE));
% cvx_begin
% variable x(9*n1,1);
% minimize(p'*x+0.5*x'*H*x);
% subject to
% A*x<=b;
% x>=0;
% cvx_end
[x,fval,exitflag] = quadprog(H,p,A,b,w1,zeros(M,1),zeros(9*n1,1),[]);
epsilon=10e-8;
for i=1:M
sv{i}.sv1=find(r1>x((i-1)*n1+1:i*n1,:)>epsilon);
b1=1./xtr{i}.L(sv{i}.sv1,:)'-x'*SS{i}.S'*makekernel(xtr{i}.data,xtr{i}.data(sv{i}.sv1,:),type,sigma)/O(i,:);
bb{i}.b=mean(b1);
end


w1=1/O(1,:)^2*x'*S1'*K{1}.train*S1*x;
w2=1/O(2,:)^2*x'*S2'*K{2}.train*S2*x;
w3=1/O(3,:)^2*x'*S3'*K{3}.train*S3*x;
nn=size(K{i}.test,1);
Yt=zeros(nn,1);
 for cvtest=1:nn
            d=x'*S1'*makekernel(xtr{1}.data,xte{1}.data,type,sigma)+x'*S2'*makekernel(xtr{2}.data,xte{2}.data,type,sigma)+x'*S3'*makekernel(xtr{3}.data,xte{3}.data,type,sigma)+O(1,:)*bb{1}.b+O(2,:)*bb{2}.b+O(3,:)*bb{3}.b;         
            %d=1/O(1,:)*(a1.*K{1}.L-bp12-bp13++bn12+bn13)'*K{1}.test'+1/O(2,:)*(a2.*K{2}.L-bp23+bn23)'*K{2}.test'+1/O(3,:)*(a3.*K{3}.L)'*K{3}.test';            
                   if(d(:,cvtest)>=0)
                        Yt(cvtest,:)=1;
                   else
                        Yt(cvtest,:)=-1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt);
[~,F]=accuracy(Yt,xte{1}.L);
p=[w1;w2;w3];
p=p/2;


