%d indicates the true label��c indicates the predicted label.
function [acc,F]=accuracy(d,c)
	MODE = all(size(d)==size(c)) & all(all((c==1) | (c==-1)));
if ~MODE
	display('illegal input!');
end
	[x,y]=size(d);
	right=0;
	for i=1:x
		if(d(i)==c(i))
			right=right+1;
		end
	end
	acc=right/x;
                TP=0;
                FN=0;
                FP=0;
                for ii=1:x
                    if(abs(c(ii,:)-1)<=0.000001&&abs(d(ii,:)-1)<=0.000001)
                         TP=TP+1;
                    end
                    if(abs(c(ii,:)-1)<=0.000001&&abs(d(ii,:)+1)<=0.000001)
                         FN=FN+1;
                    end
                    if(abs(c(ii,:)+1)<=0.000001&&abs(d(ii,:)-1)<=0.000001)
                         FP=FP+1;
                    end
                end
               F=2*TP/(TP+FN)*TP/(TP+FP)/(TP/(TP+FN)+TP/(TP+FP));
                