function [p,q,pre,F]=U_MvTSVM(U,xtr,xte,O,r1,r2,D)
M=size(xtr,2);
alpha=0.01;
[sA1,sB1] = fm(xtr{1}.A,xtr{1}.B,0,alpha);
[sA2,sB2] = fm(xtr{2}.A,xtr{2}.B,0,alpha);
[sA3,sB3] = fm(xtr{3}.A,xtr{3}.B,0,alpha);
sA=[sA1;sA2;sA3];
sB=[sB1;sB2;sB3];
type=1;
sigma=1;
for i=1:M
    K{i}.A=makekernel(xtr{i}.A,xtr{i}.data,type,sigma);
    K{i}.K=makekernel(xtr{i}.data,xtr{i}.data,type,sigma);
    K{i}.Ker=[K{i}.K ones(size(K{i}.K,1),1)];
    K{i}.A=[K{i}.A ones(size(K{i}.A,1),1)];
    K{i}.B=makekernel(xtr{i}.B,xtr{i}.data,type,sigma);
    K{i}.B=[K{i}.B ones(size(K{i}.B,1),1)];
    K{i}.L=xtr{i}.L;
    K{i}.test=makekernel(xte{i}.data,xtr{i}.data,type,sigma);
    K{i}.U=makekernel(U{i}.data,xtr{i}.data,type,sigma);
    K{i}.U=[K{i}.U ones(size(K{i}.U,1),1)];
end

E1=[2*r1*K{1}.Ker'*K{1}.Ker+O(1,:)*K{1}.A'*K{1}.A -r1*K{1}.Ker'*K{2}.Ker -r1*K{1}.Ker'*K{3}.Ker; -r1*K{2}.Ker'*K{1}.Ker 2*r1*K{2}.Ker'*K{2}.Ker+O(2,:)*K{2}.A'*K{2}.A -r1*K{2}.Ker'*K{3}.Ker;-r1*K{3}.Ker'*K{1}.Ker -r1*K{3}.Ker'*K{2}.Ker 2*r1*K{3}.Ker'*K{3}.Ker+O(3,:)*K{3}.A'*K{3}.A];
E1=(E1+E1')/2;
U_sub=blkdiag(K{1}.U,K{2}.U,K{3}.U);
B=blkdiag(K{1}.B,K{2}.B,K{3}.B);
A=blkdiag(K{1}.A,K{2}.A,K{3}.A);

E2=[2*r1*K{1}.Ker'*K{1}.Ker+O(1,:)*K{1}.B'*K{1}.B -r1*K{1}.Ker'*K{2}.Ker -r1*K{1}.Ker'*K{3}.Ker; -r1*K{2}.Ker'*K{1}.Ker 2*r1*K{2}.Ker'*K{2}.Ker+O(2,:)*K{2}.B'*K{2}.B -r1*K{2}.Ker'*K{3}.Ker;-r1*K{3}.Ker'*K{1}.Ker -r1*K{3}.Ker'*K{2}.Ker 2*r1*K{3}.Ker'*K{3}.Ker+O(3,:)*K{3}.B'*K{3}.B];
E2=(E2+E2')/2;
temp1=max(eig(E1));
temp2=max(eig(E2));
E1=E1+0.000001*temp1*eye(size(E1,1));
E2=E2+0.000001*temp2*eye(size(E2,1));
n1=size(B,1);
n2=size(A,1);
nu=size(U_sub,1);
n_a=n1+nu;
n_b=n2+nu;
epsilon=0.00001;
e1=ones(n1,1)-epsilon*ones(n1,1);
e2=ones(n2,1)-epsilon*ones(n2,1);
eu=ones(nu,1)-epsilon*ones(nu,1);
e1_sub=ones(n_a,1);
sub1=[r2*ones(n1,1);D*ones(nu,1)];
sub2=[r1*ones(n2,1);D*ones(nu,1)];
B_sub=blkdiag(B,U_sub);
A_sub=blkdiag(A,U_sub);
cvx_begin
variable a1(n1,1);
variable b1(nu,1);
minimize(-a1'*e1-b1'*eu+0.5*(a1'*B+b1'*U_sub)*inv(E1)*(B'*a1+U_sub'*b1))
subject to
a1>=0;
b1>=0;
a1<=sB*r2;
b1<=D;
cvx_end

cvx_begin
variable a2(n2,1);
variable b2(nu,1);
minimize(-a2'*(e2)-b2'*eu+0.5*(a2'*A+b2'*U_sub)*inv(E2)*(A'*a2+U_sub'*b2))
subject to
b2>=0;
a2>=0;
a2<=sA*r2;
b2<=D;
cvx_end


n=size(K{1}.L,1);
w=1/2*inv(E1)*(B'*a1+U_sub'*b1);
w1=w(1:n,:);
p1=w(n+1,:);
w2=w(n+2:2*n+1,:);
p2=w(2*n+2,:);
w3=w(2*n+3:3*n+2,:);
p3=w(3*n+3,:);
u=1/2*inv(E2)*(A'*a2+U_sub'*b2);
u1=u(1:n,:);
q1=u(n+1,:);
u2=u(n+2:2*n+1,:);
q2=u(2*n+2,:);
u3=u(2*n+3:3*n+2,:);
q3=u(3*n+3,:);

nn=size(K{i}.test,1);
 for cvtest=1:nn
        d1=O(1,:)*abs(K{1}.test*w1+p1)/sqrt(w1'*K{1}.K*w1)+O(2,:)*abs(K{2}.test*w2+p2)/sqrt(w2'*K{2}.K*w2)+O(3,:)*abs(K{3}.test*w3+p3)/sqrt(w3'*K{3}.K*w3);
        d2=O(1,:)*abs(K{1}.test*u1+q1)/sqrt(u1'*K{1}.K*u1)+O(2,:)*abs(K{2}.test*u2+q2)/sqrt(u2'*K{2}.K*u2)+O(3,:)*abs(K{3}.test*u3+q3)/sqrt(u3'*K{3}.K*u3);
                   if(d1(cvtest,:)>=d2(cvtest,:))
                        Yt(cvtest,:)=-1;
                   else
                        Yt(cvtest,:)=1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt);
[~,F]=accuracy(Yt,xte{1}.L);
p=[norm(K{1}.A*[w1;p1])^2;norm(K{2}.A*[w2;p2])^2;norm(K{3}.A*[w3;p3])^2]
q=[norm(K{1}.B*[u1;q1])^2;norm(K{2}.B*[u2;q2])^2;norm(K{3}.B*[u3;q3])^2];
