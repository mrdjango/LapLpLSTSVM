function [sA,sB]= fm(A,B,type1,alpha)

% check correct number of arguments
if ( nargin>4||nargin<4)
    help fm
else
    eplison=1e-10;
    [rxp,~]=size(A);
    [rxn,~]=size(B);
    u=0.9;
    switch type1
        case 0
            tic;
            A_cen=mean(A);
            B_cen=mean(B);
            LA=sum((repmat(A_cen,rxp,1)-A).^2,2);
            LAB=sum((repmat(B_cen,rxp,1)-A).^2,2);
            rA=sqrt(max(LA));
            LB=sum((repmat(B_cen,rxn,1)-B).^2,2);
            LBA=sum((repmat(A_cen,rxn,1)-B).^2,2);
            rB=sqrt(max(LB));
            muA=zeros(rxp,1);
            for i=1:rxp
                dis=abs(sqrt(LA(i,1))-sqrt(min(LA)));
                muA(i,1)=1-dis/(rA+eplison);
            end

            muB=zeros(rxn,1);
            for i=1:rxn
                dis=abs(sqrt(LB(i,1))-sqrt(min(LB)));
                muB(i,1)=1-dis/(rB+eplison);
            end

            rhoA=zeros(rxp,1);
            for i=1:rxp
                numup=0;  
                for j=1:rxn
                    tis= LA(i,1)*LBA(j,1);
                    if  tis>=0
                        dis=abs(sqrt(abs( LA(i,1)))-sqrt(abs( LBA(j,1))));
                    else
                        dis=abs(sqrt(abs( LA(i,1)))+sqrt(abs( LBA(j,1))));
                    end
                    if dis<=alpha
                        numup=numup+1;
                    end
                end
                numdown=numup;
                for j=1:rxp
                    tis= LA(i,1)*LA(j,1);
                    if  tis>=0
                        dis=abs(sqrt(abs( LA(i,1)))-sqrt(abs( LA(j,1))));
                    else
                        dis=abs(sqrt(abs( LA(i,1)))+sqrt(abs( LA(j,1))));
                    end
                    if dis<=alpha
                        numdown=numdown+1;
                    end
                end
                rhoA(i,1)=numup/numdown;
            end
            rhoB=zeros(rxn,1);
            for i=1:rxn
                numup=0;
                for j=1:rxp
                    tis= LB(i,1)*LAB(j,1);
                    if  tis>=0
                        dis=abs(sqrt(abs( LB(i,1)))-sqrt(abs( LAB(j,1))));
                    else
                        dis=abs(sqrt(abs( LB(i,1)))+sqrt(abs( LAB(j,1))));
                    end
                    if dis<=alpha
                        numup=numup+1;
                    end
                end
                numdown=numup;
                for j=1:rxn
                    tis= LB(i,1)*LB(j,1);
                    if  tis>=0
                        dis=abs(sqrt(abs(LB(i,1)))-sqrt(abs(LB(j,1))));
                    else
                        dis=abs(sqrt(abs(LB(i,1)))+sqrt(abs(LB(j,1))));
                    end
                    if dis<=alpha
                        numdown=numdown+1;
                    end
                end
                rhoB(i,1)=numup/numdown;
            end
            nuA=(1-muA).*rhoA;
            nuB=(1-muB).*rhoB;

            sA=zeros(rxp,1);
            for i=1:rxp
                if nuA(i,1)<1e-10
                    sA(i,1)=muA(i,1);
                elseif muA(i,1)<=nuA(i,1)
                    sA(i,1)=0;
                elseif muA(i,1)>nuA(i,1)&& nuA(i,1)>1e-10
                    sA(i,1)=(1-nuA(i,1))/(2-muA(i,1)-nuA(i,1));
                end
            end

            sB=zeros(rxn,1);
            for i=1:rxn
                if nuB(i,1)<1e-10
                    sB(i,1)=muB(i,1);
                elseif muB(i,1)<=nuB(i,1)
                    sB(i,1)=0;
                elseif muB(i,1)>nuB(i,1)&& nuB(i,1)>1e-10
                    sB(i,1)=(1-nuB(i,1))/(2-muB(i,1)-nuB(i,1));
                end
            end

        case 1
            type=1;
            sigma=1;
            K.A=makekernel(A,A,type,sigma);
            K.B=makekernel(B,B,type,sigma);
            K.AB=makekernel(A,B,type,sigma);
            K.BA=makekernel(B,A,type,sigma);
 

            LA=sqrt(diag(K.A)-2*mean(K.A,2)+mean(mean(K.A)));  
            LAB=sqrt(diag(K.A)-2*mean(K.AB,2)+mean(mean(K.B)));
            rA=max(LA);

            LB=sqrt(diag(K.B)-2*mean(K.B,2)+mean(mean(K.B))); 
            LBA=sqrt(diag(K.B)-2*mean(K.BA,2)+mean(mean(K.A)));
            rB=max(LB);

            muA=zeros(rxp,1);

            for i=1:rxp
                dis=abs(LA(i,1)-min(LA));
                muA(i,1)=1-dis/(rA+eplison);
            end

            muB=zeros(rxn,1);
            for i=1:rxn
                dis=abs(LB(i,1)-min(LB));
                muB(i,1)=1-dis/(rB+eplison);
            end

            rhoA=zeros(rxp,1);
            for i=1:rxp
                numup=0;  
                for j=1:rxn
                    tis= LA(i,1)*LBA(j,1);
                    if  tis>=0
                        dis=abs(sqrt(abs( LA(i,1)))-sqrt(abs( LBA(j,1))));
                    else
                        dis=abs(sqrt(abs( LA(i,1)))+sqrt(abs( LBA(j,1))));
                    end
                    if dis<=alpha
                        numup=numup+1;
                    end
                end
                numdown=numup;
                for j=1:rxp
                    tis= LA(i,1)*LA(j,1);
                    if  tis>=0
                        dis=abs(sqrt(abs( LA(i,1)))-sqrt(abs( LA(j,1))));
                    else
                        dis=abs(sqrt(abs( LA(i,1)))+sqrt(abs( LA(j,1))));
                    end
                    if dis<=alpha
                        numdown=numdown+1;
                    end
                end
                rhoA(i,1)=numup/numdown;
            end

            rhoB=zeros(rxn,1);
            for i=1:rxn
                numup=0;
                for j=1:rxp
                    tis= LB(i,1)*LAB(j,1);
                    if  tis>=0
                        dis=abs( LB(i,1))-abs(LAB(j,1));
                    else
                        dis=abs( LB(i,1))+abs(LAB(j,1));
                    end
                    if dis<=alpha
                        numup=numup+1;
                    end
                end
                numdown=numup;
                for j=1:rxn
                    tis= LB(i,1)*LB(j,1);
                    if  tis>=0
                        dis=abs( LB(i,1))-abs( LB(j,1));
                    else
                        dis=abs( LB(i,1))+abs( LB(j,1));
                    end
                    if dis<=alpha
                        numdown=numdown+1;
                    end
                end
                rhoB(i,1)=numup/numdown;
            end
            nuA=(1-muA).*rhoA;
            nuB=(1-muB).*rhoB;

            sA=zeros(rxp,1);
            for i=1:rxp
                if nuA(i,1)<1e-10
                    sA(i,1)=muA(i,1);
                elseif muA(i,1)<=nuA(i,1)
                    sA(i,1)=0;
                elseif muA(i,1)>nuA(i,1)&& nuA(i,1)>1e-10
                    sA(i,1)=(1-nuA(i,1))/(2-muA(i,1)-nuA(i,1));
                end
            end

            sB=zeros(rxn,1);
            for i=1:rxn
                if nuB(i,1)<1e-10
                    sB(i,1)=muB(i,1);
                elseif muB(i,1)<=nuB(i,1)
                    sB(i,1)=0;
                elseif muB(i,1)>nuB(i,1)&& nuB(i,1)>1e-10
                    sB(i,1)=(1-nuB(i,1))/(2-muB(i,1)-nuB(i,1));
                end
            end
  
    end
%     sA=mapminmax(sA, 0, 1);
%     sB=mapminmax(sB, 0, 1);
end




