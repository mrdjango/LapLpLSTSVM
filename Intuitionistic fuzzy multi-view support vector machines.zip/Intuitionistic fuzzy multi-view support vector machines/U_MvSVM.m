function [p,pre,F]=U_MvSVM(U,xtr,xte,O,r1,r2,r3)
M=size(xtr,2);
alpha=0.05;
epsilonC=0.001;
[sA1,sB1]=fm(xtr{1}.A,xtr{1}.B,0,alpha);
[sA2,sB2]=fm(xtr{2}.A,xtr{2}.B,0,alpha);
[sA3,sB3]=fm(xtr{3}.A,xtr{3}.B,0,alpha);
sA=[sA1;sB1;sA2;sB2;sA3;sB3];
type=1;
sigma=1;
for i=1:M
    K{i}.train=makekernel(xtr{i}.data,xtr{i}.data,type,sigma);
    XU{i}.data=[xtr{i}.data;U{i}.data];
    KXU{i}=makekernel(XU{i}.data,XU{i}.data,type,sigma);    
    K{i}.L=xtr{i}.L;
    K{i}.test=makekernel(xte{i}.data,xtr{i}.data,type,sigma);
end
Y1=diag(xtr{1}.L); 
num_data=size(xtr{i}.data,1);
num_universum=size(U{i}.data,1);
e_data=ones(num_data,1);
E_data=ones(num_data,num_data);
e_universum=ones(num_universum,1);
E_universum=ones(num_universum,num_universum);


S_X1=[Y1 zeros(num_data,num_data) zeros(num_data,num_data) -E_data E_data -E_data E_data zeros(num_data,num_data) zeros(num_data,num_data)];
S_X2=[zeros(num_data,num_data) Y1 zeros(num_data,num_data) E_data -E_data zeros(num_data,num_data) zeros(num_data,num_data) -E_data E_data];
S_X3=[zeros(num_data,num_data) zeros(num_data,num_data) Y1 zeros(num_data,num_data) zeros(num_data,num_data) E_data -E_data E_data -E_data];

S_U1=[-E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum) E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum)];
S_U2=[zeros(num_universum,num_universum) -E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum) E_universum zeros(num_universum,num_universum)];
S_U3=[zeros(num_universum,num_universum) zeros(num_universum,num_universum) -E_universum zeros(num_universum,num_universum) zeros(num_universum,num_universum) E_universum];

T1=blkdiag(S_X1,S_U1);
T2=blkdiag(S_X2,S_U2);
T3=blkdiag(S_X3,S_U3);
SS{1}.S=T1;
SS{2}.S=T2;
SS{3}.S=T3;
H=T1'*KXU{1}*T1/O(1,:)+T2'*KXU{2}*T2/O(2,:)+T3'*KXU{3}*T3/O(3,:);
H=(H+H')/2;

p=[-ones(3*num_data,1);epsilonC*ones(6*num_data,1);epsilonC*ones(3*num_universum,1);epsilonC*ones(3*num_universum,1)];
b=[r1*sA;r2*ones(3*num_data,1);r3*ones(3*num_universum,1);r3*ones(3*num_universum,1)];
EE=[E_data E_data];
w1=[e_data'*S_X1;e_data'*S_X2;e_data'*S_X3];
w2=[e_universum'*S_U1;e_universum'*S_U2;e_universum'*S_U3];
W1=[w1,w2];
A=blkdiag(blkdiag(E_data,E_data,E_data),blkdiag(EE,EE,EE),blkdiag(E_universum,E_universum,E_universum),blkdiag(E_universum,E_universum,E_universum));
[x,fval,exitflag] = quadprog(H,p,A,b,W1,zeros(1*M,1),zeros(9*num_data+6*num_universum,1),[]);
epsilon=10e-8;

for i=1:M
sv{i}.sv1=find(r1*sA((i-1)*num_data+1:i*num_data,:)>x((i-1)*num_data+1:i*num_data,:)>epsilon);

ttttt=size(x,1);
b1=1./xtr{i}.L(sv{i}.sv1,:)'-x'*SS{i}.S'*makekernel(XU{i}.data,XU{i}.data(sv{i}.sv1,:),type,sigma)/O(i,:);
bb{i}.b=mean(b1);
end


w1=1/O(1,:)^2*x'*T1'*KXU{1}*T1*x;
w2=1/O(2,:)^2*x'*T2'*KXU{2}*T2*x;
w3=1/O(3,:)^2*x'*T3'*KXU{3}*T3*x;

num_test=size(K{i}.test,1);
Yt=zeros(num_test,1);
 for cvtest=1:num_test
            d=x'*T1'*makekernel(XU{1}.data,xte{1}.data,type,sigma)+x'*T2'*makekernel(XU{2}.data,xte{2}.data,type,sigma)+x'*T3'*makekernel(XU{3}.data,xte{3}.data,type,sigma)+O(1,:)*bb{1}.b+O(2,:)*bb{2}.b+O(3,:)*bb{3}.b;
                   if(d(:,cvtest)>=0)
                        Yt(cvtest,:)=1;
                   else
                        Yt(cvtest,:)=-1;
                   end
 end
pre=sum(abs(Yt-xte{1}.L)<0.5)/length(Yt)
[~,F]=accuracy(Yt,xte{1}.L);
p=[w1;w2;w3];
p=p/2;


