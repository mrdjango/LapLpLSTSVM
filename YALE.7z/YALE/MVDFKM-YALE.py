import torch
import numpy as np
import utils
from metrics import cal_clustering_metric
from metrics2 import cal_predict
from scipy.sparse import coo_matrix
from sklearn.cluster import KMeans
import scipy.io as scio
import random
import warnings
import time
torch.cuda.synchronize()



class Dataset(torch.utils.data.Dataset):
    def __init__(self, X, X2):
        self.X = X
        self.X2 = X2

    def __getitem__(self, idx):
        return self.X[:, idx], self.X2[:, idx], idx

    def __len__(self):
        return self.X.shape[1]

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def weights_init(m):
    # if type(m) == torch.nn.Linear:
    #     torch.nn.init.xavier_uniform(m.weight)
    #     torch.nn.init.constant(m.bias,0)
    classname = m.__class__.__name__
    if classname.find('Linear') != -1:
        m.weight.data.normal_(0.0, pow(2/(m.weight.data.size(0)+m.weight.data.size(1)),1/2))                                             
        m.bias.data.fill_(0)

class PretrainDoubleLayer(torch.nn.Module):
    def __init__(self, X, dim, device, act, batch_size=128, lr=10**-3, epoch_pre=10):
        super(PretrainDoubleLayer, self).__init__()
        self.X = X
        self.dim = dim
        self.lr = lr
        self.device = device
        self.enc = torch.nn.Linear(X.shape[0], self.dim)
        self.dec = torch.nn.Linear(self.dim, X.shape[0])
        self.batch_size = batch_size
        self.act = act
        self.epoch_pre=epoch_pre

    def forward(self, x):
        if self.act is not None:
            z = self.act(self.enc(x))
            return z, self.act(self.dec(z))
        else:
            z = self.enc(x)
            return z, self.dec(z)

    def _build_loss(self, x, recons_x):
        size = x.shape[0]
        return torch.norm(x-recons_x, p='fro')**2 / size

    def run(self):
        self.to(self.device)
        optimizer = torch.optim.Adam(self.parameters(), lr=self.lr)
        train_loader = torch.utils.data.DataLoader(Dataset(self.X, self.X), batch_size=self.batch_size, shuffle=True)
        loss = 0
        for epoch in range(self.epoch_pre):
            for i, batch in enumerate(train_loader):
                x, _, _ = batch
                optimizer.zero_grad()
                _, recons_x = self(x)
                loss = self._build_loss(x, recons_x)
                loss.backward()
                optimizer.step()
        print('epoch-{}: loss={}'.format(epoch, loss.item()))
        Z, _ = self(self.X.t())
        return Z.t()


class MVDeepFuzzyKMeans(torch.nn.Module):
    def __init__(self, X, X2, labels, layers=None, layers2=None, lam=1, lam2=1, sigma=None, gamma=1, q_num=1, lr=10**-3, 
                 device=None, batch_size=128, p_train=True, epoch_num=30, table=[], pur_table=[], nmi_table=[], epoch_pre=10):
        super(MVDeepFuzzyKMeans, self).__init__()
        if layers is None:
            print('Layer Error!!!')
        if device is None:
            device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.layers = layers
        self.layers2 = layers2
        self.device = device
        if not isinstance(X, torch.Tensor):
            X = torch.Tensor(X)
            X2 = torch.Tensor(X2)
        self.X = X.to(device)
        self.X2 = X2.to(device)
        self.epoch_num=epoch_num
        self.p_train=p_train
        self.labels = labels
        self.gamma = gamma
        self.q_num=q_num
        self.lam = lam
        self.lam2=lam2
        self.sigma = sigma
        self.epoch_pre=epoch_pre
        self.batch_size = batch_size
        self.n_clusters = len(np.unique(self.labels))
        self.alpha=pow(np.array([0.5,0.5]),self.q_num)
        self.lr = lr
        self.table=table
        self.pur_table=pur_table
        self.nmi_table=nmi_table
        self._build_up()

    def _build_up(self):
        self.act = torch.tanh
        "First view of the deep network"
        self.enc1 = torch.nn.Linear(self.layers[0], self.layers[1])
        self.enc2 = torch.nn.Linear(self.layers[1], self.layers[2])
        self.dec1 = torch.nn.Linear(self.layers[2], self.layers[1])
        self.dec2 = torch.nn.Linear(self.layers[1], self.layers[0])
        "Second view of the deep network"
        self.enc3 = torch.nn.Linear(self.layers2[0], self.layers2[1])
        self.enc4 = torch.nn.Linear(self.layers2[1], self.layers2[2])
        self.dec3 = torch.nn.Linear(self.layers2[2], self.layers2[1])
        self.dec4 = torch.nn.Linear(self.layers2[1], self.layers2[0])


    def forward(self, x, x2):
        'fist view'
        z = self.act(self.enc1(x))
        z = self.act(self.enc2(z))
        recons_x = self.act(self.dec1(z))
        recons_x = self.act(self.dec2(recons_x))
        'second view'
        z2 = self.act(self.enc3(x2))
        z2 = self.act(self.enc4(z2))
        recons_x2 = self.act(self.dec3(z2))
        recons_x2 = self.act(self.dec4(recons_x2))
        return z, recons_x, z2, recons_x2
    

    def _build_loss(self, z, x, d, u, recons_x, alpha, view):
        size = x.shape[0]
        loss = 1/2 * torch.norm(x - recons_x, p='fro') ** 2 / size
        t = d*u  # t: m * c
        if view ==1:
            distances = utils.distance(z.t(), self.centroids)
            loss += (self.lam / 2 * alpha[view-1]* torch.trace(distances.t().matmul(t)) / size)
            loss += self.lam2 * (self.enc1.weight.norm()**2 + self.enc1.bias.norm()**2) / size
            loss += self.lam2 * (self.enc2.weight.norm()**2 + self.enc2.bias.norm()**2) / size
            loss += self.lam2 * (self.dec1.weight.norm()**2 + self.dec1.bias.norm()**2) / size
            loss += self.lam2 * (self.dec2.weight.norm()**2 + self.dec2.bias.norm()**2) / size
        else:
            distances = utils.distance(z.t(), self.centroids2)
            loss += (self.lam / 2 * alpha[view-1]* torch.trace(distances.t().matmul(t)) / size)
            loss += self.lam2 * (self.enc3.weight.norm()**2 + self.enc3.bias.norm()**2) / size
            loss += self.lam2 * (self.enc4.weight.norm()**2 + self.enc4.bias.norm()**2) / size
            loss += self.lam2 * (self.dec3.weight.norm()**2 + self.dec3.bias.norm()**2) / size
            loss += self.lam2 * (self.dec4.weight.norm()**2 + self.dec4.bias.norm()**2) / size
        return loss
    

    def run(self):
        self.to(self.device)
        if self.p_train==True:
            self.pretrain()
        Z, _, Z2, _ = self(self.X.t(),self.X2.t())
        Z = Z.t().detach()  #Z1=300*1854
        Z2 = Z2.t().detach()
        idx = random.sample(list(range(Z.shape[1])), self.n_clusters)
        self.centroids = Z[:, idx] + 10 ** -6  #centroids(c)=300*10
        self.centroids2 = Z2[:, idx] + 10 ** -6
        self._update_U(Z,Z2)
        self._update_alpha(Z, Z2, self.U)
        # D = self._update_D(Z)
        # self.clustering(D, Z)
        print('Starting training......')
        train_loader = torch.utils.data.DataLoader(Dataset(self.X, self.X2), batch_size=self.batch_size, shuffle=True)
        optimizer = torch.optim.Adam(self.parameters(), lr=self.lr)
        loss = 0
        for epoch in range(self.epoch_num):
            D = self._update_D(Z,1) #D=1854*10
            D2 = self._update_D(Z2,2) #D2=1854*10
            for i, batch in enumerate(train_loader):
                x, x2, idx = batch
                optimizer.zero_grad()
                z, recons_x, z2, recons_x2 = self(x, x2)
                d = D[idx, :]
                u = self.U[idx, :]
                d2 = D2[idx, :]
                loss = self._build_loss(z, x, d, u, recons_x, self.alpha, 1)+self._build_loss(z2, x2, d2, u, recons_x2, self.alpha, 2)
                loss.backward()
                optimizer.step()
                Z, _, Z2, _ = self(self.X.t(),self.X2.t())
                Z = Z.t().detach()  #Z=300*1854
                Z2 = Z2.t().detach()
                # D = self._update_D(Z)
                # for i in range(20):
                self.clustering(Z, Z2, 1)
            _, y_pred = self.U.max(dim=1)
            y_pred = y_pred.detach().cpu() + 1
            y_pred = y_pred.numpy()
            acc,pur,nmi=cal_predict(self.labels, y_pred)
            #acc, nmi = cal_clustering_metric(self.labels, y_pred)
            if epoch ==self.epoch_num-1:
                self.table.append(acc)
                self.pur_table.append(pur)
                self.nmi_table.append(nmi)
            print('epoch-{}, loss={}, ACC={}, Purity={} NMI={}'.format(epoch, loss.item(), acc, pur, nmi))

    def pretrain(self):
        string_template = 'Start pretraining-{} for the first view......'
        print(string_template.format(1))
        pre1 = PretrainDoubleLayer(self.X, self.layers[1], self.device, self.act, lr=self.lr, epoch_pre=self.epoch_pre)
        Z = pre1.run()
        self.enc1.weight = pre1.enc.weight
        self.enc1.bias = pre1.enc.bias
        self.dec2.weight = pre1.dec.weight
        self.dec2.bias = pre1.dec.bias
        print(string_template.format(2))
        pre2 = PretrainDoubleLayer(Z.detach(), self.layers[2], self.device, self.act, lr=self.lr, epoch_pre=self.epoch_pre)
        pre2.run()
        self.enc2.weight = pre2.enc.weight
        self.enc2.bias = pre2.enc.bias
        self.dec1.weight = pre2.dec.weight
        self.dec1.bias = pre2.dec.bias
        
        string_template = 'Start pretraining-{} for the second view......'
        print(string_template.format(1))
        pre1 = PretrainDoubleLayer(self.X2, self.layers2[1], self.device, self.act, lr=self.lr, epoch_pre=self.epoch_pre)
        Z = pre1.run()
        self.enc3.weight = pre1.enc.weight
        self.enc3.bias = pre1.enc.bias
        self.dec4.weight = pre1.dec.weight
        self.dec4.bias = pre1.dec.bias
        print(string_template.format(2))
        pre2 = PretrainDoubleLayer(Z.detach(), self.layers2[2], self.device, self.act, lr=self.lr, epoch_pre=self.epoch_pre)
        pre2.run()
        self.enc4.weight = pre2.enc.weight
        self.enc4.bias = pre2.enc.bias
        self.dec3.weight = pre2.dec.weight
        self.dec3.bias = pre2.dec.bias

    def _update_D(self, Z, v):
        if self.sigma is None:
            return torch.ones([Z.shape[1], self.centroids.shape[1]]).to(self.device)
            print('sigma is None!!')
        else:
            if v==1:
                distances = utils.distance(Z, self.centroids, False)
                return (1 + self.sigma) * (distances + 2 * self.sigma) / (2 * ((distances + self.sigma)**2)) 
            else:
                distances = utils.distance(Z, self.centroids2, False)
                return (1 + self.sigma) * (distances + 2 * self.sigma) / (2 * ((distances + self.sigma)**2)) 

    def clustering(self, Z, Z2, max_iter=1):
        for i in range(max_iter):
            D = self._update_D(Z,1)
            D2 = self._update_D(Z2,2)
            T = D * self.U  #T=1854*10
            self.centroids = Z.matmul(T) / T.sum(dim=0).reshape([1, -1]) #更新c
            T = D2 * self.U  #T=1854*10
            self.centroids2 = Z2.matmul(T) / T.sum(dim=0).reshape([1, -1]) #更新c
            self._update_U(Z, Z2)
            self.alpha[0], self.alpha[1]= self._update_alpha(Z, Z2, self.U)
            #print(self.alpha)
            self.alpha=pow(self.alpha,self.q_num)
            
            

    def _update_U(self, Z, Z2):
        if self.sigma is None:
            distances = self.alpha[0]*utils.distance(Z, self.centroids, True)
            +self.alpha[1]*utils.distance(Z2, self.centorids2,True)
        else:
            distances = self.alpha[0]*adaptive_loss(utils.distance(Z, self.centroids, False), self.sigma)
            +self.alpha[1]*adaptive_loss(utils.distance(Z2, self.centroids2, False), self.sigma)
        U = torch.exp(-distances / self.gamma)
        self.U = U / U.sum(dim=1).reshape([-1, 1])
        
    def _update_alpha(self, Z, Z2, u):
        A=torch.sum(u*adaptive_loss(utils.distance(Z, self.centroids, False), self.sigma))
        A2=torch.sum(u*adaptive_loss(utils.distance(Z2, self.centroids2, False), self.sigma))
        down=pow(A,1/(1-self.q_num))+pow(A2,1/(1-self.q_num))
        return pow(A,1/(1-self.q_num))/down, pow(A2,1/(1-self.q_num))/down

def adaptive_loss(D, sigma):
    return (1 + sigma) * D * D / (D + sigma)


if __name__ == '__main__':
    import data_loader as loader
    starttime = time.time()
    warnings.filterwarnings('ignore')
    data, data2, labels = loader.load_data(loader.YALE)
    data = data.T 
    data2 = data2.T 
    avg=[]
    pu=[]
    nm=[]
    for ml in range(1): 
        for epoch_num in range(1):
                acc_table=[]
                pur_table=[]
                nmi_table=[]
                for times in range(10):
                    #print('lam={}'.format(lam))
                    mvdfkm = MVDeepFuzzyKMeans(data, data2, labels, [data.shape[0], 512, 14], [data2.shape[0], 512, 30], lam=10**-5, lam2=10**-2, sigma=0.8, 
                                           gamma=0.1, q_num=0.1, batch_size=83, lr=pow(10,-4), p_train=True, epoch_num=30, table=acc_table, pur_table=pur_table, nmi_table=nmi_table,epoch_pre=5)
                    'epoch_num最后细调'
                    setup_seed(times+1)
                    mvdfkm.apply(weights_init)
                    mvdfkm.run()
                aver=np.mean(acc_table)
                aver_p=np.mean(pur_table)
                aver_n=np.mean(nmi_table)
                #print(acc_table)
                #print(pur_table)
                #print(nmi_table)
                avg.append(round(aver,4))
                pu.append(round(aver_p,4))
                nm.append(round(aver_n,4))
                print('avg:',avg)
                print('avg:',pu)
                print('avg:',nm)
    avg=torch.Tensor(avg)
    value,predict=torch.max(avg,dim=0)
    print('site:',value,predict,pu[predict],nm[predict],predict)
    endtime = time.time()
    print('time:',endtime-starttime)